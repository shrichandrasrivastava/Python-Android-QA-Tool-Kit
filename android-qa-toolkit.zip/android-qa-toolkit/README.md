# Android QA Toolkit

Python utilities for the kind of QA and system-validation work done across
Android OEM programs: logcat/bugreport crash-ANR triage, release sign-off
reporting, API regression testing, and ADB-based connectivity sanity checks.

Built to reflect a QA engineering workflow spanning firmware/OTA validation,
functional & regression testing, and cross-functional release readiness
sign-off (realme, Tecno, Lava, Gionee-style device programs).

## Features

| Module | What it does |
|---|---|
| `adb_log_analyzer` | Scans `adb logcat` / bugreport text dumps for Java crashes, ANRs, native crashes, kernel panics, watchdog/system_server deaths, and low-memory kills. Exports CSV / JSON / HTML defect reports. |
| `report_generator` | Aggregates test case results (Pass/Fail/Blocked/Not Run) from a CSV export (TestRail/HP ALM style) into pass-rate stats and a GO / NO-GO release-readiness HTML dashboard. |
| `api_tester` | Declarative, `requests`-based API regression runner — a lightweight Python alternative to a Postman collection or REST Assured suite. |
| `connectivity_check` | Wraps `adb shell settings get global ...` calls to sanity-check Wi-Fi / Bluetooth / mobile data / airplane mode state across connected devices. |
| `cli` | Single command-line entry point tying all of the above together. |

## Project Structure

```
android-qa-toolkit/
├── src/android_qa_toolkit/
│   ├── adb_log_analyzer/       # crash / ANR / kernel-panic detection
│   ├── report_generator/       # test execution & release sign-off reports
│   ├── api_tester/              # API regression test runner
│   ├── connectivity_check/      # ADB Wi-Fi/BT/mobile-data sanity checks
│   └── cli.py                   # unified CLI
├── tests/                       # pytest unit tests (with mocked network calls)
├── sample_data/                 # sample logcat, test-result CSV, API test JSON
├── .github/workflows/ci.yml     # GitHub Actions: tests on 3.10/3.11/3.12
├── pyproject.toml
└── requirements.txt
```

## Installation

```bash
git clone https://github.com/<your-username>/android-qa-toolkit.git
cd android-qa-toolkit
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -e ".[dev]"
```

## Usage

### 1. Analyze a logcat / bugreport dump

```bash
python -m android_qa_toolkit.cli logcat sample_data/sample_bugreport.txt \
    --html out/logcat_report.html --csv out/logcat_report.csv
```

Detects `FATAL EXCEPTION` (Java crashes), `ANR in <pkg>`, native `Fatal signal`
crashes, kernel panics, `Watchdog`/`system_server` deaths, and low-memory
kills, then produces a defect-tracker-ready report.

### 2. Generate a release sign-off report

```bash
python -m android_qa_toolkit.cli testreport sample_data/sample_test_results.csv \
    --html out/test_report.html
```

Outputs pass-rate, a breakdown by suite, the list of open Critical/High
failures, and a GO / CONDITIONAL GO / NO-GO recommendation.

### 3. Run an API regression suite

```python
from android_qa_toolkit.api_tester.api_test_suite import ApiTestRunner

runner = ApiTestRunner()
cases = ApiTestRunner.load_cases("sample_data/sample_api_tests.json")
results = runner.run(cases)
print(runner.summary())
```

### 4. Run device connectivity sanity checks

Requires Android platform-tools `adb` on PATH and an authorized, connected
device.

```bash
python -m android_qa_toolkit.cli connectivity
```

## Running Tests

```bash
pytest --cov=android_qa_toolkit tests/
```

All tests run offline — API tests mock `requests` calls so no live network
access is required in CI.

## Tech Stack

Python 3.10+, `requests`, `pytest`, `argparse`, standard library `csv`/`json`.
Designed to sit alongside Playwright/TypeScript UI automation and
Jenkins/JIRA/TestRail pipelines in a broader QA toolchain.

## License

MIT — see [LICENSE](LICENSE).

## Author

**Shrichandra Srivastava** — Senior QA & System Validation Engineer
[LinkedIn](https://linkedin.com/in/shrichandra) · shri0sri@gmail.com

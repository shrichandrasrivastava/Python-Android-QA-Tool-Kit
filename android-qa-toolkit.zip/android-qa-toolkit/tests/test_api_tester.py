from unittest.mock import patch, MagicMock

from android_qa_toolkit.api_tester.api_test_suite import ApiTestCase, ApiTestRunner


def _mock_response(status_code=200, json_data=None):
    mock_resp = MagicMock()
    mock_resp.status_code = status_code
    mock_resp.json.return_value = json_data or {}
    return mock_resp


@patch("android_qa_toolkit.api_tester.api_test_suite.requests.request")
def test_passing_case(mock_request):
    mock_request.return_value = _mock_response(200, {"ok": True})
    case = ApiTestCase(
        name="basic get",
        method="GET",
        url="https://example.com/api",
        expected_status=200,
        expected_json_contains={"ok": True},
    )
    runner = ApiTestRunner()
    results = runner.run([case])
    assert results[0].passed is True
    assert runner.summary()["passed"] == 1


@patch("android_qa_toolkit.api_tester.api_test_suite.requests.request")
def test_failing_status_case(mock_request):
    mock_request.return_value = _mock_response(500, {})
    case = ApiTestCase(
        name="expects 200 gets 500",
        method="GET",
        url="https://example.com/api",
        expected_status=200,
    )
    runner = ApiTestRunner()
    results = runner.run([case])
    assert results[0].passed is False
    assert "Expected status 200" in results[0].error


@patch("android_qa_toolkit.api_tester.api_test_suite.requests.request")
def test_json_mismatch_case(mock_request):
    mock_request.return_value = _mock_response(200, {"device": "RMX1"})
    case = ApiTestCase(
        name="json mismatch",
        method="GET",
        url="https://example.com/api",
        expected_status=200,
        expected_json_contains={"device": "RMX2"},
    )
    runner = ApiTestRunner()
    results = runner.run([case])
    assert results[0].passed is False
    assert "device" in results[0].error

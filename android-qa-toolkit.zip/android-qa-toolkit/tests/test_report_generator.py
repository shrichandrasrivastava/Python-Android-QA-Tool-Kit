from pathlib import Path

from android_qa_toolkit.report_generator.report_generator import TestExecutionReport

SAMPLE_CSV = Path(__file__).parent.parent / "sample_data" / "sample_test_results.csv"


def test_loads_csv():
    report = TestExecutionReport.from_csv(SAMPLE_CSV)
    assert report.total() == 10


def test_status_counts():
    report = TestExecutionReport.from_csv(SAMPLE_CSV)
    counts = report.status_counts()
    assert counts.get("Pass", 0) == 7
    assert counts.get("Fail", 0) == 1
    assert counts.get("Blocked", 0) == 1
    assert counts.get("Not Run", 0) == 1


def test_pass_rate_excludes_not_run():
    report = TestExecutionReport.from_csv(SAMPLE_CSV)
    # 9 executed (excluding 1 Not Run), 7 passed => 77.78%
    assert report.pass_rate() == 77.78


def test_release_recommendation_is_nogo_with_critical_open_failure():
    report = TestExecutionReport.from_csv(SAMPLE_CSV)
    # TC-002 is High priority + Fail -> should trigger NO-GO
    assert report.release_recommendation().startswith("NO-GO")


def test_html_export(tmp_path):
    report = TestExecutionReport.from_csv(SAMPLE_CSV)
    out_file = tmp_path / "report.html"
    report.to_html(out_file)
    assert out_file.exists()
    assert "Release Test Summary" in out_file.read_text(encoding="utf-8")

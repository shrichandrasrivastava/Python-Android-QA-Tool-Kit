from pathlib import Path

from android_qa_toolkit.adb_log_analyzer.analyzer import LogcatAnalyzer

SAMPLE_LOG = Path(__file__).parent.parent / "sample_data" / "sample_bugreport.txt"


def test_detects_java_crash():
    analyzer = LogcatAnalyzer()
    analyzer.parse_file(SAMPLE_LOG)
    report = analyzer.build_report()
    types = report.counts_by_type()
    assert types.get("Java Crash", 0) >= 1


def test_detects_anr():
    analyzer = LogcatAnalyzer()
    analyzer.parse_file(SAMPLE_LOG)
    report = analyzer.build_report()
    assert report.counts_by_type().get("ANR", 0) >= 1


def test_detects_native_crash():
    analyzer = LogcatAnalyzer()
    analyzer.parse_file(SAMPLE_LOG)
    report = analyzer.build_report()
    assert report.counts_by_type().get("Native Crash", 0) >= 1


def test_report_has_critical_issues():
    analyzer = LogcatAnalyzer()
    analyzer.parse_file(SAMPLE_LOG)
    report = analyzer.build_report()
    assert report.critical_count() >= 3


def test_empty_log_produces_no_issues():
    analyzer = LogcatAnalyzer()
    analyzer.parse_text("just a normal info line\nanother normal line\n")
    report = analyzer.build_report()
    assert len(report.issues) == 0

"""
Device Connectivity Sanity Checker (ADB)
==========================================

Wraps common `adb shell` calls used during connectivity smoke/sanity
passes (Wi-Fi, Bluetooth, mobile data, airplane mode) so a quick health
check can run unattended against one or more connected devices before a
full regression pass starts.

Requires the Android platform-tools `adb` binary on PATH and a device
connected/authorized (`adb devices`).

Usage:

    from android_qa_toolkit.connectivity_check.connectivity_check import DeviceConnectivityChecker

    checker = DeviceConnectivityChecker()
    for device_id in checker.list_devices():
        print(device_id, checker.run_all_checks(device_id))
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass


@dataclass
class ConnectivityStatus:
    device_id: str
    wifi_enabled: bool | None
    bluetooth_enabled: bool | None
    mobile_data_enabled: bool | None
    airplane_mode: bool | None
    errors: list[str]


class AdbCommandError(RuntimeError):
    pass


class DeviceConnectivityChecker:
    def __init__(self, adb_path: str = "adb"):
        self.adb_path = adb_path

    # ------------------------------------------------------------------
    # Low-level adb helpers
    # ------------------------------------------------------------------

    def _run(self, args: list[str], timeout: float = 10.0) -> str:
        try:
            result = subprocess.run(
                [self.adb_path, *args],
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False,
            )
        except FileNotFoundError as exc:
            raise AdbCommandError(
                "adb binary not found on PATH. Install Android platform-tools."
            ) from exc
        except subprocess.TimeoutExpired as exc:
            raise AdbCommandError(f"adb command timed out: {args}") from exc

        if result.returncode != 0 and result.stderr.strip():
            raise AdbCommandError(result.stderr.strip())
        return result.stdout.strip()

    def list_devices(self) -> list[str]:
        output = self._run(["devices"])
        devices = []
        for line in output.splitlines()[1:]:
            line = line.strip()
            if line.endswith("device"):
                devices.append(line.split()[0])
        return devices

    def _shell(self, device_id: str, cmd: str) -> str:
        return self._run(["-s", device_id, "shell", cmd])

    # ------------------------------------------------------------------
    # Individual checks
    # ------------------------------------------------------------------

    def is_wifi_enabled(self, device_id: str) -> bool:
        out = self._shell(device_id, "settings get global wifi_on")
        return out.strip() == "1"

    def is_bluetooth_enabled(self, device_id: str) -> bool:
        out = self._shell(device_id, "settings get global bluetooth_on")
        return out.strip() == "1"

    def is_mobile_data_enabled(self, device_id: str) -> bool:
        out = self._shell(device_id, "settings get global mobile_data")
        return out.strip() == "1"

    def is_airplane_mode_on(self, device_id: str) -> bool:
        out = self._shell(device_id, "settings get global airplane_mode_on")
        return out.strip() == "1"

    # ------------------------------------------------------------------
    # Aggregate
    # ------------------------------------------------------------------

    def run_all_checks(self, device_id: str) -> ConnectivityStatus:
        status = ConnectivityStatus(
            device_id=device_id, wifi_enabled=None, bluetooth_enabled=None,
            mobile_data_enabled=None, airplane_mode=None, errors=[],
        )
        checks = {
            "wifi_enabled": self.is_wifi_enabled,
            "bluetooth_enabled": self.is_bluetooth_enabled,
            "mobile_data_enabled": self.is_mobile_data_enabled,
            "airplane_mode": self.is_airplane_mode_on,
        }
        for field_name, fn in checks.items():
            try:
                setattr(status, field_name, fn(device_id))
            except AdbCommandError as exc:
                status.errors.append(f"{field_name}: {exc}")
        return status

"""
API Test Suite Runner
======================

A lightweight, Python-native alternative to running a Postman collection
or REST Assured suite. Test cases are declared as simple dicts (or loaded
from JSON) describing request + expected-response assertions, then run
and reported in one pass — useful for backend/API regression checks
around device-cloud services (OTA metadata, account/auth endpoints, etc.).

Example test case definition:

    {
        "name": "GET status 200",
        "method": "GET",
        "url": "https://httpbin.org/get",
        "expected_status": 200,
        "expected_json_contains": {"url": "https://httpbin.org/get"}
    }
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import requests


@dataclass
class ApiTestCase:
    name: str
    method: str
    url: str
    headers: dict = field(default_factory=dict)
    json_body: dict | None = None
    expected_status: int = 200
    expected_json_contains: dict = field(default_factory=dict)
    timeout: float = 10.0


@dataclass
class ApiTestResult:
    name: str
    passed: bool
    status_code: int | None
    duration_ms: float
    error: str = ""


class ApiTestRunner:
    def __init__(self, base_url: str = ""):
        self.base_url = base_url
        self.results: list[ApiTestResult] = []

    @staticmethod
    def load_cases(path: str | Path) -> list[ApiTestCase]:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return [ApiTestCase(**case) for case in data]

    def run(self, cases: list[ApiTestCase]) -> list[ApiTestResult]:
        self.results = []
        for case in cases:
            self.results.append(self._run_one(case))
        return self.results

    def _run_one(self, case: ApiTestCase) -> ApiTestResult:
        url = self.base_url + case.url if self.base_url and not case.url.startswith("http") else case.url
        start = time.perf_counter()
        try:
            response = requests.request(
                method=case.method.upper(),
                url=url,
                headers=case.headers,
                json=case.json_body,
                timeout=case.timeout,
            )
            duration_ms = (time.perf_counter() - start) * 1000

            if response.status_code != case.expected_status:
                return ApiTestResult(
                    name=case.name, passed=False, status_code=response.status_code,
                    duration_ms=duration_ms,
                    error=f"Expected status {case.expected_status}, got {response.status_code}",
                )

            if case.expected_json_contains:
                try:
                    body = response.json()
                except ValueError:
                    return ApiTestResult(
                        name=case.name, passed=False, status_code=response.status_code,
                        duration_ms=duration_ms, error="Response was not valid JSON",
                    )
                mismatch = _find_mismatch(body, case.expected_json_contains)
                if mismatch:
                    return ApiTestResult(
                        name=case.name, passed=False, status_code=response.status_code,
                        duration_ms=duration_ms, error=mismatch,
                    )

            return ApiTestResult(
                name=case.name, passed=True, status_code=response.status_code,
                duration_ms=duration_ms,
            )

        except requests.RequestException as exc:
            duration_ms = (time.perf_counter() - start) * 1000
            return ApiTestResult(
                name=case.name, passed=False, status_code=None,
                duration_ms=duration_ms, error=str(exc),
            )

    def summary(self) -> dict[str, Any]:
        total = len(self.results)
        passed = sum(1 for r in self.results if r.passed)
        return {
            "total": total,
            "passed": passed,
            "failed": total - passed,
            "pass_rate": round(100 * passed / total, 2) if total else 0.0,
        }


def _find_mismatch(body: Any, expected: dict) -> str:
    """Returns an error string if any expected key/value isn't present in
    the response body (shallow contains-check), else empty string."""
    if not isinstance(body, dict):
        return "Response JSON is not an object"
    for key, expected_value in expected.items():
        if key not in body:
            return f"Missing key '{key}' in response"
        if body[key] != expected_value:
            return f"Key '{key}': expected {expected_value!r}, got {body[key]!r}"
    return ""

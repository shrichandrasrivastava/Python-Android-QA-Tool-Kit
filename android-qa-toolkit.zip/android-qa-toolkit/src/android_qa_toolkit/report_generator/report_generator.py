"""
Test Execution & Release Sign-off Report Generator
====================================================

Takes a set of test case results (as would be exported from TestRail /
HP ALM / a CSV test matrix) and produces:

  * pass/fail/blocked statistics by test suite and priority
  * a go/no-go style release-readiness summary
  * an HTML dashboard suitable for sharing with PMs / engineering leads

Input format (CSV or list of dicts), one row per test case:

    test_id, suite, priority, status, module, notes

Where status is one of: Pass, Fail, Blocked, Not Run
"""

from __future__ import annotations

import csv
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable

VALID_STATUSES = {"Pass", "Fail", "Blocked", "Not Run"}


@dataclass
class TestCaseResult:
    test_id: str
    suite: str
    priority: str
    status: str
    module: str = ""
    notes: str = ""


class TestExecutionReport:
    """Aggregates test case results into release-readiness metrics."""

    def __init__(self, results: Iterable[TestCaseResult]):
        self.results = list(results)

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------

    @classmethod
    def from_csv(cls, path: str | Path) -> "TestExecutionReport":
        path = Path(path)
        results = []
        with path.open(newline="", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                status = row.get("status", "Not Run").strip()
                if status not in VALID_STATUSES:
                    status = "Not Run"
                results.append(
                    TestCaseResult(
                        test_id=row.get("test_id", ""),
                        suite=row.get("suite", "General"),
                        priority=row.get("priority", "Medium"),
                        status=status,
                        module=row.get("module", ""),
                        notes=row.get("notes", ""),
                    )
                )
        return cls(results)

    # ------------------------------------------------------------------
    # Metrics
    # ------------------------------------------------------------------

    def total(self) -> int:
        return len(self.results)

    def status_counts(self) -> dict[str, int]:
        return dict(Counter(r.status for r in self.results))

    def pass_rate(self) -> float:
        executed = [r for r in self.results if r.status != "Not Run"]
        if not executed:
            return 0.0
        passed = sum(1 for r in executed if r.status == "Pass")
        return round(100 * passed / len(executed), 2)

    def by_suite(self) -> dict[str, dict[str, int]]:
        breakdown: dict[str, dict[str, int]] = defaultdict(
            lambda: {s: 0 for s in VALID_STATUSES}
        )
        for r in self.results:
            breakdown[r.suite][r.status] += 1
        return dict(breakdown)

    def critical_failures(self) -> list[TestCaseResult]:
        return [
            r for r in self.results
            if r.status in ("Fail", "Blocked") and r.priority in ("Critical", "High")
        ]

    def release_recommendation(self) -> str:
        """A simple heuristic go/no-go recommendation, the kind used to
        back a quality sign-off discussion — not a substitute for
        engineering judgement."""
        crit_fails = self.critical_failures()
        rate = self.pass_rate()
        if crit_fails:
            return f"NO-GO: {len(crit_fails)} open Critical/High priority failure(s)."
        if rate < 90:
            return f"CONDITIONAL GO: pass rate {rate}% is below the 90% bar."
        return f"GO: pass rate {rate}% with no open Critical/High failures."

    # ------------------------------------------------------------------
    # Export
    # ------------------------------------------------------------------

    def to_html(self, path: str | Path, title: str = "Release Test Summary") -> None:
        path = Path(path)
        counts = self.status_counts()
        suite_rows = "\n".join(
            f"<tr><td>{suite}</td>"
            + "".join(f"<td>{data.get(s, 0)}</td>" for s in
                      ["Pass", "Fail", "Blocked", "Not Run"])
            + "</tr>"
            for suite, data in self.by_suite().items()
        )
        crit_rows = "\n".join(
            f"<tr><td>{r.test_id}</td><td>{r.suite}</td><td>{r.priority}</td>"
            f"<td>{r.status}</td><td>{r.notes}</td></tr>"
            for r in self.critical_failures()
        ) or "<tr><td colspan='5'>None</td></tr>"

        html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>{title}</title>
<style>
body {{ font-family: Arial, sans-serif; margin: 24px; }}
h1 {{ font-size: 20px; }} h2 {{ font-size: 16px; margin-top: 28px; }}
table {{ border-collapse: collapse; width: 100%; margin-top: 8px; }}
th, td {{ border: 1px solid #ccc; padding: 6px 10px; font-size: 13px; text-align: left; }}
th {{ background: #222; color: #fff; }}
.banner {{ padding: 10px 14px; border-radius: 4px; font-weight: bold; display: inline-block; }}
.go {{ background: #d4edda; color: #155724; }}
.nogo {{ background: #f8d7da; color: #721c24; }}
.conditional {{ background: #fff3cd; color: #856404; }}
</style></head>
<body>
<h1>{title}</h1>
<p>Generated: {datetime.now().isoformat(timespec="seconds")} &nbsp;|&nbsp;
Total test cases: {self.total()} &nbsp;|&nbsp; Pass rate: {self.pass_rate()}%</p>
<div class="banner {"go" if self.release_recommendation().startswith("GO") else "nogo" if self.release_recommendation().startswith("NO-GO") else "conditional"}">
{self.release_recommendation()}
</div>
<h2>Status Breakdown</h2>
<table><tr><th>Status</th><th>Count</th></tr>
{"".join(f"<tr><td>{k}</td><td>{v}</td></tr>" for k, v in counts.items())}
</table>
<h2>By Suite</h2>
<table><tr><th>Suite</th><th>Pass</th><th>Fail</th><th>Blocked</th><th>Not Run</th></tr>
{suite_rows}
</table>
<h2>Open Critical / High Priority Failures</h2>
<table><tr><th>Test ID</th><th>Suite</th><th>Priority</th><th>Status</th><th>Notes</th></tr>
{crit_rows}
</table>
</body></html>"""
        path.write_text(html, encoding="utf-8")

"""
Command-line entry point for android_qa_toolkit.

Examples
--------
Analyze a bugreport/logcat dump for crashes and ANRs:

    python -m android_qa_toolkit.cli logcat sample_data/sample_bugreport.txt --html out/logcat_report.html

Generate a release sign-off report from a test-results CSV:

    python -m android_qa_toolkit.cli testreport sample_data/sample_test_results.csv --html out/test_report.html

Run a device connectivity sanity check (requires adb + connected device):

    python -m android_qa_toolkit.cli connectivity
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from android_qa_toolkit.adb_log_analyzer.analyzer import LogcatAnalyzer
from android_qa_toolkit.report_generator.report_generator import TestExecutionReport
from android_qa_toolkit.connectivity_check.connectivity_check import (
    DeviceConnectivityChecker,
    AdbCommandError,
)


def _cmd_logcat(args: argparse.Namespace) -> int:
    analyzer = LogcatAnalyzer()
    analyzer.parse_file(args.log_file)
    report = analyzer.build_report()

    print(f"Scanned {report.total_lines_scanned} lines from {args.log_file}")
    print(f"Found {len(report.issues)} issue(s): {report.counts_by_type()}")
    print(f"Critical issues: {report.critical_count()}")

    if args.csv:
        Path(args.csv).parent.mkdir(parents=True, exist_ok=True)
        report.to_csv(args.csv)
        print(f"CSV written to {args.csv}")
    if args.json:
        Path(args.json).parent.mkdir(parents=True, exist_ok=True)
        report.to_json(args.json)
        print(f"JSON written to {args.json}")
    if args.html:
        Path(args.html).parent.mkdir(parents=True, exist_ok=True)
        report.to_html(args.html)
        print(f"HTML report written to {args.html}")
    return 0


def _cmd_testreport(args: argparse.Namespace) -> int:
    report = TestExecutionReport.from_csv(args.results_csv)
    print(f"Total test cases: {report.total()}")
    print(f"Status breakdown: {report.status_counts()}")
    print(f"Pass rate: {report.pass_rate()}%")
    print(f"Recommendation: {report.release_recommendation()}")

    if args.html:
        Path(args.html).parent.mkdir(parents=True, exist_ok=True)
        report.to_html(args.html)
        print(f"HTML report written to {args.html}")
    return 0


def _cmd_connectivity(args: argparse.Namespace) -> int:
    checker = DeviceConnectivityChecker()
    try:
        devices = checker.list_devices()
    except AdbCommandError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    if not devices:
        print("No authorized devices found. Run 'adb devices' to check.")
        return 1

    for device_id in devices:
        status = checker.run_all_checks(device_id)
        print(f"\nDevice: {status.device_id}")
        print(f"  Wi-Fi enabled:      {status.wifi_enabled}")
        print(f"  Bluetooth enabled:  {status.bluetooth_enabled}")
        print(f"  Mobile data:        {status.mobile_data_enabled}")
        print(f"  Airplane mode:      {status.airplane_mode}")
        if status.errors:
            print(f"  Errors: {status.errors}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="android-qa-toolkit",
        description="QA automation utilities for Android/firmware validation.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_logcat = subparsers.add_parser("logcat", help="Analyze a logcat/bugreport file")
    p_logcat.add_argument("log_file", help="Path to logcat or bugreport text file")
    p_logcat.add_argument("--csv", help="Write CSV report to this path")
    p_logcat.add_argument("--json", help="Write JSON report to this path")
    p_logcat.add_argument("--html", help="Write HTML report to this path")
    p_logcat.set_defaults(func=_cmd_logcat)

    p_report = subparsers.add_parser("testreport", help="Generate release sign-off report from test results")
    p_report.add_argument("results_csv", help="Path to test-results CSV")
    p_report.add_argument("--html", help="Write HTML dashboard to this path")
    p_report.set_defaults(func=_cmd_testreport)

    p_conn = subparsers.add_parser("connectivity", help="Run ADB connectivity sanity checks on connected devices")
    p_conn.set_defaults(func=_cmd_connectivity)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())

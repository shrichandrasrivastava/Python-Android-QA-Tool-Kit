"""
ADB Logcat Analyzer
====================

Parses Android `adb logcat` / bugreport text dumps and flags common
release-blocking issues that a QA engineer triages during firmware and
OS-build validation:

  * Java crashes            -> "FATAL EXCEPTION"
  * ANRs                    -> "ANR in <package>"
  * Native / tombstone crashes -> "Fatal signal", "*** *** *** *** ***"
  * Kernel panics            -> "Kernel panic"
  * Watchdog / system_server death -> "Watchdog", "system_server"

Typical use (mirrors day-to-day ADB log triage during regression cycles):

    from android_qa_toolkit.adb_log_analyzer.analyzer import LogcatAnalyzer

    analyzer = LogcatAnalyzer()
    analyzer.parse_file("bugreport.txt")
    report = analyzer.build_report()
    report.to_csv("defects.csv")
    report.to_html("defects.html")
"""

from __future__ import annotations

import csv
import json
import re
from collections import Counter
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Iterable


# --------------------------------------------------------------------------
# Data model
# --------------------------------------------------------------------------

@dataclass
class Issue:
    """A single detected defect signature found in a log file."""

    issue_type: str          # e.g. "Java Crash", "ANR", "Native Crash"
    severity: str            # "Critical" | "High" | "Medium"
    package: str             # best-effort guessed package / process name
    timestamp: str           # timestamp as captured in the log, if present
    line_number: int
    summary: str             # short one-line summary for a defect tracker
    raw_snippet: str         # a few surrounding lines for context


@dataclass
class AnalysisReport:
    """Aggregated results of a logcat/bugreport scan."""

    source_file: str
    generated_at: str
    total_lines_scanned: int
    issues: list[Issue] = field(default_factory=list)

    # --- summary helpers -------------------------------------------------

    def counts_by_type(self) -> dict[str, int]:
        return dict(Counter(i.issue_type for i in self.issues))

    def counts_by_package(self) -> dict[str, int]:
        return dict(Counter(i.package for i in self.issues))

    def critical_count(self) -> int:
        return sum(1 for i in self.issues if i.severity == "Critical")

    # --- exporters, mirroring how findings get handed off to a defect
    #     tracker such as JIRA / HP ALM / TestRail -------------------------

    def to_csv(self, path: str | Path) -> None:
        path = Path(path)
        with path.open("w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(
                ["Type", "Severity", "Package", "Timestamp", "Line",
                 "Summary"]
            )
            for issue in self.issues:
                writer.writerow(
                    [issue.issue_type, issue.severity, issue.package,
                     issue.timestamp, issue.line_number, issue.summary]
                )

    def to_json(self, path: str | Path) -> None:
        path = Path(path)
        payload = {
            "source_file": self.source_file,
            "generated_at": self.generated_at,
            "total_lines_scanned": self.total_lines_scanned,
            "summary": {
                "by_type": self.counts_by_type(),
                "by_package": self.counts_by_package(),
                "critical_count": self.critical_count(),
            },
            "issues": [asdict(i) for i in self.issues],
        }
        path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def to_html(self, path: str | Path) -> None:
        path = Path(path)
        rows = "\n".join(
            f"<tr><td>{i.issue_type}</td><td class='{i.severity.lower()}'>"
            f"{i.severity}</td><td>{i.package}</td><td>{i.timestamp}</td>"
            f"<td>{i.line_number}</td><td>{i.summary}</td></tr>"
            for i in self.issues
        )
        html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>Logcat Analysis Report</title>
<style>
body {{ font-family: Arial, sans-serif; margin: 24px; }}
h1 {{ font-size: 20px; }}
table {{ border-collapse: collapse; width: 100%; }}
th, td {{ border: 1px solid #ccc; padding: 6px 10px; font-size: 13px; text-align: left; }}
th {{ background: #222; color: #fff; }}
.critical {{ color: #b00020; font-weight: bold; }}
.high {{ color: #c26a00; font-weight: bold; }}
.medium {{ color: #856404; }}
</style></head>
<body>
<h1>Logcat Analysis Report</h1>
<p>Source: {self.source_file} &nbsp;|&nbsp; Generated: {self.generated_at}
&nbsp;|&nbsp; Lines scanned: {self.total_lines_scanned}
&nbsp;|&nbsp; Total issues: {len(self.issues)}</p>
<table>
<tr><th>Type</th><th>Severity</th><th>Package</th><th>Timestamp</th>
<th>Line</th><th>Summary</th></tr>
{rows}
</table>
</body></html>"""
        path.write_text(html, encoding="utf-8")


# --------------------------------------------------------------------------
# Analyzer
# --------------------------------------------------------------------------

class LogcatAnalyzer:
    """Scans logcat/bugreport text for known crash and stability signatures."""

    PATTERNS: dict[str, tuple[re.Pattern, str]] = {
        "Java Crash": (re.compile(r"FATAL EXCEPTION"), "Critical"),
        "ANR": (re.compile(r"ANR in (\S+)"), "Critical"),
        "Native Crash": (re.compile(r"Fatal signal \d+"), "Critical"),
        "Kernel Panic": (re.compile(r"Kernel panic"), "Critical"),
        "System Server Death": (re.compile(r"system_server.*died|Watchdog"), "High"),
        "Low Memory Kill": (re.compile(r"Low on memory|lowmemorykiller"), "Medium"),
    }

    PACKAGE_PATTERN = re.compile(r"Process:\s*([\w\.]+)")
    TIMESTAMP_PATTERN = re.compile(
        r"^(\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}\.\d{3})"
    )

    def __init__(self, context_lines: int = 2) -> None:
        self.context_lines = context_lines
        self._issues: list[Issue] = []
        self._lines: list[str] = []
        self._source_file = "<unset>"

    def parse_file(self, path: str | Path) -> None:
        path = Path(path)
        text = path.read_text(encoding="utf-8", errors="ignore")
        self._source_file = str(path)
        self.parse_text(text)

    def parse_text(self, text: str) -> None:
        self._lines = text.splitlines()
        self._issues = []

        current_package = "unknown"
        for idx, line in enumerate(self._lines):
            pkg_match = self.PACKAGE_PATTERN.search(line)
            if pkg_match:
                current_package = pkg_match.group(1)

            for issue_type, (pattern, severity) in self.PATTERNS.items():
                match = pattern.search(line)
                if not match:
                    continue

                package = current_package
                if issue_type == "ANR" and match.groups():
                    package = match.group(1)

                ts_match = self.TIMESTAMP_PATTERN.search(line)
                timestamp = ts_match.group(1) if ts_match else ""

                snippet = self._context(idx)
                self._issues.append(
                    Issue(
                        issue_type=issue_type,
                        severity=severity,
                        package=package,
                        timestamp=timestamp,
                        line_number=idx + 1,
                        summary=line.strip()[:180],
                        raw_snippet=snippet,
                    )
                )

    def _context(self, idx: int) -> str:
        start = max(0, idx - self.context_lines)
        end = min(len(self._lines), idx + self.context_lines + 1)
        return "\n".join(self._lines[start:end])

    def build_report(self) -> AnalysisReport:
        return AnalysisReport(
            source_file=self._source_file,
            generated_at=datetime.now().isoformat(timespec="seconds"),
            total_lines_scanned=len(self._lines),
            issues=self._issues,
        )


def analyze_files(paths: Iterable[str | Path]) -> AnalysisReport:
    """Convenience helper to merge findings across multiple log files
    (e.g. one bugreport per device under test in a regression pass)."""
    combined = AnalysisReport(
        source_file="multiple",
        generated_at=datetime.now().isoformat(timespec="seconds"),
        total_lines_scanned=0,
    )
    for p in paths:
        analyzer = LogcatAnalyzer()
        analyzer.parse_file(p)
        report = analyzer.build_report()
        combined.total_lines_scanned += report.total_lines_scanned
        combined.issues.extend(report.issues)
    return combined

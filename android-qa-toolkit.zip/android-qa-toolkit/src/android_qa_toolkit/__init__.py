"""
android_qa_toolkit
===================

A small collection of QA / test-automation utilities built around the kind
of work done in mobile OEM software validation: ADB log triage, crash/ANR
detection, defect report generation, API test automation, and basic
Wi-Fi/Bluetooth connectivity checks over ADB.
"""

__version__ = "0.1.0"
